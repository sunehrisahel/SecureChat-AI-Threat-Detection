"""
Web server for the AI Chatbot with Prompt Injection Protection.
Serves the chat UI at http://localhost:3000
"""

import sys
import os
import logging
from datetime import datetime, timezone

# Allow imports from the chatbot/ directory
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel

import config
import detector_client
import llm_client

# Logging setup
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - web_server - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

app = FastAPI(title="AI Chatbot Web Interface")

# CORS — allow all origins so the frontend can talk to this server
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Conversation history (resets on server restart)
conversation_history: list = []


def reset_history():
    """Reset conversation history to just the system message."""
    global conversation_history
    conversation_history = [
        {"role": "system", "content": config.SYSTEM_PROMPT}
    ]


# Initialize history on startup
reset_history()


# ── Request / Response models ──────────────────────────────────────────────────

class ChatRequest(BaseModel):
    message: str


class ChatResponse(BaseModel):
    reply: str
    verdict: str
    risk_score: int
    matched_patterns: list
    blocked: bool


# ── Endpoints ──────────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    """Check if this server and the detector are alive."""
    detector_status = "online"
    try:
        import requests as req
        r = req.get("http://localhost:8000/health", timeout=3)
        if r.status_code != 200:
            detector_status = "offline"
    except Exception:
        detector_status = "offline"

    return {"status": "ok", "detector": detector_status}


@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """Receive a user message, check it, and return a response."""
    user_text = request.message.strip()

    if not user_text:
        return ChatResponse(
            reply="Please type a message.",
            verdict="safe",
            risk_score=0,
            matched_patterns=[],
            blocked=False
        )

    # Step 1 — Run through the injection detector
    detection = detector_client.check_message(user_text)
    verdict = detection.get("verdict", "safe")
    risk_score = detection.get("risk_score", 0)
    matched_patterns = detection.get("matched_patterns", [])

    logger.info(f"Message checked | verdict={verdict} score={risk_score}")

    # Step 2 — Block if high risk
    if verdict in config.BLOCKED_VERDICTS:
        blocked_reply = (
            f"⚠️ Your message was blocked by the security filter "
            f"(verdict: {verdict}, score: {risk_score}). "
            f"Please rephrase your request."
        )
        return ChatResponse(
            reply=blocked_reply,
            verdict=verdict,
            risk_score=risk_score,
            matched_patterns=matched_patterns,
            blocked=True
        )

    # Step 3 — Safe: add to history and call the LLM
    conversation_history.append({"role": "user", "content": user_text})

    # Trim history if needed
    system_msg = conversation_history[0]
    messages = conversation_history[1:]
    if len(messages) > config.MAX_HISTORY:
        messages = messages[-config.MAX_HISTORY:]
    conversation_history.clear()
    conversation_history.append(system_msg)
    conversation_history.extend(messages)

    reply = llm_client.get_response(conversation_history)
    conversation_history.append({"role": "assistant", "content": reply})

    return ChatResponse(
        reply=reply,
        verdict=verdict,
        risk_score=risk_score,
        matched_patterns=matched_patterns,
        blocked=False
    )


@app.post("/clear")
async def clear():
    """Reset the conversation history."""
    reset_history()
    logger.info("Conversation history cleared")
    return {"status": "cleared"}


# ── Static files ───────────────────────────────────────────────────────────────

# Serve index.html at the root
@app.get("/")
async def root():
    return FileResponse(os.path.join(os.path.dirname(__file__), "static", "index.html"))

# Mount static folder for any other assets
app.mount("/static", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "static")), name="static")


# ── Entry point ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("\n🛡️  AI Chatbot Web Interface")
    print("─" * 40)
    print("Chat UI  →  http://localhost:3000")
    print("Detector →  http://localhost:8000")
    print("─" * 40 + "\n")
    uvicorn.run("web_server:app", host="0.0.0.0", port=3000, reload=True)
